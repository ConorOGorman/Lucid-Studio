<?php

/**
 * The version of the SQLite driver.
 *
 * This constant needs to be updated on plugin release!
 */
define( 'SQLITE_DRIVER_VERSION', '2.2.15' );
